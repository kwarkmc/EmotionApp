from flask import Flask, request
from werkzeug.utils import secure_filename
import os
from datetime import datetime
import pydub
import math

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_file():
    # 파일을 저장할 디렉토리 경로
    UPLOAD_FOLDER = 'm4a'

    # 클라이언트로부터 파일을 받아옴
    file = request.files['file']

    # 파일 이름을 안전하게 저장하기 위해 secure_filename() 함수를 사용함
    filename = secure_filename(file.filename)

    # 파일을 디렉토리에 저장함
    file.save(os.path.join(UPLOAD_FOLDER, filename))

    # 파일 이름에 오늘 날짜가 포함되어 있지 않으면 리턴
    today = datetime.today().strftime('%y%m%d')
    if today not in filename:
        return 'no today files'

    # wav 파일로 변환하여 저장할 폴더 경로 생성
    foldername = os.path.join(os.getcwd(), today)
    os.makedirs(foldername, exist_ok=True)

    # m4a 파일을 wav 파일로 변환하여 저장
    sound = pydub.AudioSegment.from_file(os.path.join(UPLOAD_FOLDER, filename))
    duration = len(sound)
    segment_length = 5000 # 5초
    for i, start_time in enumerate(range(0, duration, segment_length)):
        end_time = start_time + segment_length
        segment = sound[start_time:end_time]
        new_filename = f"{filename.split('.')[0]}_{i}.wav"
        segment.export(os.path.join(foldername, new_filename), format='wav')

    ret = 12345
    return str(ret)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
