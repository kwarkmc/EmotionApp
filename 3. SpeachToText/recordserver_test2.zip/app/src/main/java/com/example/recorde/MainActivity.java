package com.example.recorde;

import okhttp3.MultipartBody;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static final String AUDIO_FILE_NAME = "recording.wav";
    private static final String AUDIO_FILE_PATH = Environment.getExternalStorageDirectory().getPath() + "/" + AUDIO_FILE_NAME;

    private Button mRecordButton;
    private Button mStopButton;
    private Button mUploadButton;

    private MediaRecorder mRecorder;
    private boolean mIsRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecordButton = findViewById(R.id.record_button);
        mStopButton = findViewById(R.id.stop_button);
        mUploadButton = findViewById(R.id.upload_button);

        mRecordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRecording();
            }
        });

        mStopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRecording();
            }
        });

        mUploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadFile();
            }
        });

        // 권한 요청
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_RECORD_AUDIO_PERMISSION);
        }
    }

    private void startRecording() {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
        mRecorder.setOutputFile(AUDIO_FILE_PATH);

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            Log.e(TAG, "prepare() failed");
        }

        mRecorder.start();
        mIsRecording = true;

        mRecordButton.setEnabled(false);
        mStopButton.setEnabled(true);

        Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_SHORT).show();
    }

    private void stopRecording() {
        if (mIsRecording) {
            mRecorder.stop();
            mRecorder.release();
            mRecorder = null;
            mIsRecording = false;

            mRecordButton.setEnabled(true);
            mStopButton.setEnabled(false);
            mUploadButton.setEnabled(true); // upload 버튼 활성화

            Toast.makeText(getApplicationContext(), "Recording stopped", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadFile() {
        if (new File(AUDIO_FILE_PATH).exists()) {
            new UploadFileTask().execute(AUDIO_FILE_PATH);
        } else {
            Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_SHORT).show();
        }
    }

// 파일

    private class UploadFileTask extends AsyncTask<String, Void, String> {

        private OkHttpClient client = new OkHttpClient();

        @Override
        protected String doInBackground(String... params) {
            String filePath = params[0];
            File file = new File(filePath);

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("audio_file", file.getName(), RequestBody.create(MediaType.parse("audio/wav"), file))
                    .build();

            Request request = new Request.Builder()
                    .url("http://192.168.55.244:5000/upload")
                    .post(requestBody)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (IOException e) {
                Log.e(TAG, "IOException", e);
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                Toast.makeText(getApplicationContext(), "Upload successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "Upload failed", Toast.LENGTH_SHORT).show();
            }
        }
    }}
