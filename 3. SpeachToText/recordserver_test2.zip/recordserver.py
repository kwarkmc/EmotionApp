import logging

logging.basicConfig(level=logging.DEBUG)

from flask import Flask, request
import os

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB

@app.route('/upload', methods=['POST'])
def upload():
    if 'audio_file' not in request.files:
        app.logger.error('No file uploaded')
        return 'No file uploaded', 400

    file = request.files['audio_file']

    if file.filename == '':
        app.logger.error('No file selected')
        return 'No file selected', 400

    if file:
        filename = file.filename
        file.save(os.path.join('uploads', filename))
        app.logger.info('File saved as %s', filename)
        return os.path.join('uploads', filename), 200

    app.logger.error('Upload failed')
    return 'Upload failed', 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)